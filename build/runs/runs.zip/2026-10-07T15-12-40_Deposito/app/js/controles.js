let nivelActual = 0;
let estado;

/**
 * Inicializa el juego en un nivel específico.
 * @param {number} i - El índice del nivel a cargar (0-based).
 */
function iniciarNivel(i) {
    nivelActual = i;
    // Crear el nuevo estado basado en los niveles definidos
    estado = Reglas.crearEstado(NIVELES[i]);

    // Limpiar mensajes y dibujar la escena inicial
    document.getElementById('mensaje').textContent = "¡Empieza a moverte!";
    dibujar(estado, nivelActual + 1);
}

/**
 * Maneja el movimiento del operario basado en las teclas presionadas.
 */
function manejarTeclado(event) {
    // Si ya se ganó el nivel, ignorar movimientos hasta reiniciar/siguiente
    if (Reglas.ganado(estado)) {
        return;
    }

    let direccion = null;
    switch (event.key) {
        case 'ArrowUp':
            direccion = "arriba";
            break;
        case 'ArrowDown':
            direccion = "abajo";
            break;
        case 'ArrowLeft':
            direccion = "izquierda";
            break;
        case 'ArrowRight':
            direccion = "derecha";
            break;
    }

    if (direccion) {
        event.preventDefault(); // Prevenir scroll del navegador
        // Calcular el nuevo estado después de intentar mover
        estado = Reglas.mover(estado, direccion);
        dibujar(estado, nivelActual + 1);

        // Verificar si se ganó el nivel y actualizar mensaje
        if (Reglas.ganado(estado)) {
            document.getElementById('mensaje').textContent = "¡Nivel completado!";
        } else if (estado.movimientos > estado.cajas.length * 2) {
             // Mensaje de advertencia si el jugador se queda quieto mucho tiempo o es un nivel difícil
             // Esto es opcional, pero ayuda a la UX.
        }
    }
}

/**
 * Maneja el botón Reiniciar.
 */
function manejarReiniciar() {
    iniciarNivel(nivelActual);
}

/**
 * Maneja el botón Siguiente Nivel.
 */
function manejarSiguiente() {
    // Verificar si existe un siguiente nivel en el array NIVELES
    if (nivelActual + 1 < NIVELES.length) {
        iniciarNivel(nivelActual + 1);
    } else {
        document.getElementById('mensaje').textContent = "¡Has completado todos los niveles!";
        // Deshabilitar el botón si no hay más niveles
        document.getElementById('btn-siguiente').disabled = true;
    }
}

// --- Inicialización de Event Listeners y Juego ---

// 1. Listener para las teclas de flecha
document.addEventListener('keydown', manejarTeclado);

// 2. Listener para el botón Reiniciar
document.getElementById('btn-reiniciar').addEventListener('click', manejarReiniciar);

// 3. Listener para el botón Siguiente Nivel
document.getElementById('btn-siguiente').addEventListener('click', manejarSiguiente);


// Iniciar el juego en el nivel 0 al cargar la página
iniciarNivel(0);
